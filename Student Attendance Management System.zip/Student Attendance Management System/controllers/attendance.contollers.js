import attendance from "../models/attendance.models.js"
import students from "../models/student.models.js"



//mark attendance

export const markAttendance = async (req, res) => {

    let { studentId, date, status } = req.body

    if (!studentId || !date || !status) {
        return res.status(400).json({ status: false, message: "Invalid Request" })
    }

    try {
        const amark = await attendance.findOne({ studentId: studentId, date: date })

        if (amark != null) {

            await attendance.create({ studentId: studentId, date: date, status: status })

            return res.status(201).json({ status: true, message: "Attendance marked successfully", amark })
        }
        return res.json({ status: false, message: "student not found or cannot mark attendance" })

    }

    catch (error) {
        console.log(error)
        return res.json({ status: false, message: "Something went wrong" })
    }


}



